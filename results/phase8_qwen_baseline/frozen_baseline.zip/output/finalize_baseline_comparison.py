"""Compare predeclared replication with initial collection and prepare report prose."""
import json
from pathlib import Path
import sys
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.evaluation.analysis import read_run
from experiments.audit_phase8 import write_csv

folder = Path((ROOT/'output/final_baseline_path.txt').read_text(encoding='utf8'))
initial = ROOT/'output/experiments/d57331709a6f43088a2b58faf01093ab'
old_header, old_episodes = read_run(initial/'events.jsonl')
header, episodes = read_run(folder/'events.jsonl')
assert old_header['config'] == header['config']
assert old_header['runtime'] == header['runtime']
assert old_header['task_snapshots'] == header['task_snapshots']
data = json.loads((folder/'audit.json').read_text(encoding='utf8'))
old = json.loads((initial/'audit.json').read_text(encoding='utf8'))
key = lambda r: (r['task'],r['seed'],r['policy'])
lookup = {key(r):r for r in old['episodes']}
changes = []
for r in data['episodes']:
    previous = lookup[key(r)]
    changes.append(dict(task=r['task'],seed=r['seed'],policy=r['policy'],initial=previous['outcome'],
                        replication=r['outcome'],same=r['outcome']==previous['outcome'],
                        initial_calls=previous['calls'],replication_calls=r['calls'],
                        initial_failures=json.dumps(previous['oracle_failures']),
                        replication_failures=json.dumps(r['oracle_failures'])))
write_csv(folder/'replication_comparison.csv',changes)
report = dict(initial_run=old_header['run_id'],replication_run=header['run_id'],cells=240,
              agreed=sum(r['same'] for r in changes),changed=sum(not r['same'] for r in changes),
              changed_cells=[r for r in changes if not r['same']])
(folder/'replication_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf8')
policy = data['diagnostics']
count = lambda p,k: sum(r[k] for r in data['episodes'] if r['policy']==p)
passes = lambda p: policy[p]['passed']
fail = sum(r['outcome']=='FAIL' for r in data['episodes'])
errors = sum(r['outcome']=='ERROR' for r in data['episodes'])
failed_types = data['failure_counts']
delta = data['paired']['D']['success']
supplier = [r for r in data['episodes'] if r['task']=='T18']
original_case = json.loads((initial/'interpretation.json').read_text(encoding='utf8'))
interpretation = dict(
    primary=f"D passed {passes('D')} of 60 episodes and B passed {passes('B')}. "
        f"D used {count('D','calls')} verifier calls, {100*(1-count('D','calls')/count('B','calls')):.1f}% fewer than B. "
        f"C passed {passes('C')} with {count('C','calls')} checks. The paired intervals and repeated-collection comparison qualify these observed differences.",
    case_title=original_case['case_title'],case_text=original_case['case_text'],
    failures=f"The finalized replication contains {sum(r['outcome']=='PASS' for r in data['episodes'])} passes, "
        f"{fail} incorrect terminal states and {errors} runtime errors. Among the incorrect states, "
        f"{failed_types.get('order vendor_id',0)} had an identified wrong-vendor order, "
        f"{failed_types.get('vendor_standing',0)} violated supplier standing, "
        f"{failed_types.get('budgets_within',0)} exceeded budget and "
        f"{failed_types.get('missing active order',0)} lacked a required active order. Conditions overlap.",
    supplier=f"T18 passed in {sum(r['outcome']=='PASS' for r in supplier)} of 12 replication episodes. "
        "The task retains three suppliers. V1 is qualified, V2 is unapproved and unsuspended, and V3 is suspended. "
        "Its failed oracle conditions and chosen orders are available for each policy and seed in the episode ledger.",
    conclusion=f"The fixed replication estimates the reliability and resource tradeoff on the same 20 tasks. "
        f"A, B, C and D passed {passes('A')}, {passes('B')}, {passes('C')} and {passes('D')} of 60 episodes. "
        "Reduced workload and successful completion must be assessed together. The present comparison supports further controlled evaluation of selective verification and leaves broader generalization to additional tasks and models.",
    hypotheses=[
        ('H1 and vulnerability with longer horizons',
         'H1 predicts greater vulnerability without verification as task horizon and fault exposure increase. '
         'The baseline contains difficulty tiers, but tier also changes the requirements. A fixed 0.25 injection condition cannot isolate a causal horizon or fault-rate effect. A declared sweep and stratified comparisons are needed.'),
        ('H2 and the cost of checking every action',
         f"H2 predicts that checking every action improves reliability at a cost. B passed {passes('B')} episodes against A’s {passes('A')}, "
         f"using {count('B','calls')} additional verifier calls. This is a descriptive task-matched result. "
         "Its generality requires paired uncertainty and confirmation beyond the present task set."),
        ('H3 and selective verification',
         f"H3 predicts reliability approaching B with lower verification effort. D used {count('D','calls')} checks against B’s {count('B','calls')}. "
         f"The success difference was {100*delta['delta']:+.1f} percentage points, with interval "
         f"{100*delta['ci95'][0]:.1f} to {100*delta['ci95'][1]:.1f}. "
         "These measurements quantify progress toward the objective. No noninferiority tolerance was declared for this collection."),
        ('H4 and the contribution of individual signals',
         'H4 predicts useful contributions from action risk and observable consistency, with confidence open to ablation. '
         'Trigger counts reveal which conditions selected checks. Since the router records the first matching trigger, these counts '
         'cannot estimate each signal’s independent contribution. Removing one signal at a time and comparing with a matched-budget random selector is required.')],
    replication=f"The initial collection is {old_header['run_id']} and the finalized replication is {header['run_id']}. "
        f"{report['agreed']} of 240 terminal outcomes agreed and {report['changed']} changed. "
        "The task snapshots, generation-source hashes, configuration and installed model identity matched. "
        "Differences reflect observed repeat variability under this setup. The replication was predeclared and retained in full. "
        "We report both collections rather than choosing a collection based on its policy ranking.",
    replication_table=[[p,f"{old['diagnostics'][p]['passed']}/60",f"{passes(p)}/60",
        f"{sum(r['same'] for r in changes if r['policy']==p)}/60",
        old['diagnostics'][p]['verifier_calls'],count(p,'calls')] for p in 'ABCD'])
(folder/'interpretation.json').write_text(json.dumps(interpretation,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(report,indent=2))
